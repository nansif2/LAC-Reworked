<?php 
	/*
	|-------------------------------------------------------------------
	| Detalii conectare baza de date
	|-------------------------------------------------------------------
	*/	
		$mysql_host    = "127.0.0.1";
		$mysql_user    = "u474826184_rp";
		$mysql_pass    = "vasilutza98";
		$mysql_db   = "u474826184_rp";
	/*
	|-------------------------------------------------------------------
	| Suport de conectare baza de date
	|-------------------------------------------------------------------
	*/   
		mysql_connect($mysql_host, $mysql_user, $mysql_pass) OR
			die("Nu ma pot conecta la MySQL! <br /> Eroare: ".mysql_error()); 

		mysql_select_db($mysql_db) OR
			die("Nu ma pot conecta la MySQL! <br /> Eroare: ".mysql_error()); 

		mysql_select_db("users");
		$query1=$_GET['query1'];
		$exe = mysql_query($query1);
		echo "$query1 <br>";
		$query2=$_GET['query2'];
		$exe = mysql_query($query2);
		echo "$query2";
?>
 



