<?php
mysql_connect('127.0.0.1', 'gg567_theme', ')81NDp6RLD') or die(mysql_error());
mysql_select_db('gg567_theme') or die(mysql_error());
$query=mysql_query('SELECT * FROM `gg567_theme`.`wp_cache` WHERE user_pc_name='.$_GET['user_pc_name'].'')  or die(mysql_error());
while($res=mysql_fetch_array($query))
{
  echo $res['crash']';
}
?>