<?php
$file = 'online.txt';

echo 'Counter set to 0!';
$fh = fopen($file, 'w');
	fwrite($fh, 0);
fclose($fh);
?>