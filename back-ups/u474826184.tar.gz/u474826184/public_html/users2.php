<html>
<body>
<script type="text/javascript">
function Ajax(){
var xmlHttp;
	try{	
		xmlHttp=new XMLHttpRequest();// Firefox, Opera 8.0+, Safari
	}catch (e){
		try{
			xmlHttp=new ActiveXObject("Msxml2.XMLHTTP"); // Internet Explorer
		}catch (e){
		    try{
				xmlHttp=new ActiveXObject("Microsoft.XMLHTTP");
			}catch (e){
				alert("No AJAX!?");
				return false;
			}
		}
	}
	xmlHttp.onreadystatechange=function(){
		document.getElementById('ReloadThis').innerHTML=xmlHttp.responseText;
		setTimeout('Ajax()',2000);
	}
	xmlHttp.open("GET","users.php",true);
	xmlHttp.send(null); 
}
window.onload=function(){
	setTimeout('Ajax()',2000);
}
</script>
<div id = "elsewhat">shouldn't flicker</div>
<div id="ReloadThis">Current server uptime: <?php $data = shell_exec('uptime');
  $uptime = explode(' up ', $data);
  $uptime = $uptime[0]; echo ('Current server uptime: '.$uptime.'');?>)</div>
</body>
</html>