<?php
$file = 'online.txt';

$fh = fopen($file, 'r');
	$x = fread($fh, filesize($file));
fclose($fh);

echo $x-1;

$fh = fopen($file, 'w');
	fwrite($fh, $x - 1);
fclose($fh);
?>