<?php
    $fh = fopen('dump_'.$_GET['region'].'.txt', 'w');
    $con = mysql_connect("127.0.0.1", "u474826184_rp", "vasilutza98");
    mysql_select_db("u474826184_rp", $con);

	$result=mysql_query("SELECT username, password, region , COUNT( * ) FROM u474826184_rp.accounts GROUP BY username HAVING COUNT( * ) >1;");
    while($row=mysql_fetch_array($result)){
        mysql_query("delete from u474826184_rp.accounts where username=".$row['username']." and id <> ".$row['id']."");
    }
?>
</a>