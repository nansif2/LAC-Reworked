<?php
    $fh = fopen('dump_'.$_GET['region'].'.txt', 'w');
    $con = mysql_connect("127.0.0.1", "u474826184_rp", "vasilutza98");
    mysql_select_db("u474826184_rp", $con);

    /* insert field values into data.txt */
	
    $result = mysql_query("SELECT * FROM u474826184_rp.accounts WHERE `region`='".$_GET['region']."' ORDER BY `id` ASC;");   
    while ($row = mysql_fetch_array($result)) {       
		fwrite($fh, $row['username']);
		fwrite($fh, ":");
		fwrite($fh, $row['password']);
                                              
        fwrite($fh, "\n");
    }
    fclose($fh);
	$file = 'dump_'.$_GET['region'].'.txt';
	header('Content-type: text/plain');
	header('Content-Length: '.filesize($file));
	header('Content-Disposition: attachment; filename='.$file);
	readfile($file);
?> 