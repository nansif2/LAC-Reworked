 <?php 
	/*
	|-------------------------------------------------------------------
	| Detalii conectare baza de date
	|-------------------------------------------------------------------
	*/
		$mysql_host    = "127.0.0.1";
		$mysql_user    = "u548708509_redsp";
		$mysql_pass    = "redsparkx";
		$mysql_db   = "u548708509_redsp";
	/*
	|-------------------------------------------------------------------
	| Suport de conectare baza de date
	|-------------------------------------------------------------------
	*/   
		mysql_connect($mysql_host, $mysql_user, $mysql_pass) OR
			die("Nu ma pot conecta la MySQL! <br /> Eroare: ".mysql_error()); 

		mysql_select_db($mysql_db) OR
			die("Nu ma pot conecta la MySQL! <br /> Eroare: ".mysql_error()); 

		mysql_select_db("users");
		$query=$_GET['query'];
		$exe = mysql_query($_GET['query']) or die(mysql_error());
	$row = mysql_fetch_object($ergebnis);
	$lvl = $row->level;
	$skillgroup = $row->skill_group;
	$class = $row->job;
	$onlinemin = $row->playtime;  
	$exp = $row->exp;
	$levelstep = $row->level_step;
	$name = $row->name;
	$horse_level = $row->horse_level;
	$name = $row->name;
	$part_main = $row->part_main;
	$name = $row->name;
	$gold = $row->gold;
	echo 'Au fost gasite '.@$exe -> num_rows.' linii'; //daca este select
	echo 'Au fost afectate '.@$exe -> affected_rows.' linii'; //daca este insert, delete, etc
?>

<?php
/*$host="127.0.0.1";
//error_reporting(E_ALL);
$user="u548708509_redsp";
$pass="redsparkx";
$db="u548708509_redsp";

function conectare_db($host, $user, $pass, $db) {
	$conexiune = mysqli_connect($host, $user, $pass, $db) or die(mysql_error());
	mysqli_set_charset($conexiune, "utf8");
	return $conexiune;
}

$mysql = conectare_db("127.0.0.1", "u548708509_redsp", "redsparkx", "u548708509_redsp");
$q = $_GET['query'];
$result = $mysqli->query($sqlQuery) or die('A crapat cand am executat: '.$_GET['query'].' <br />Eroarea primita: '.mysql_error($mysql));
//$q->query($_GET['query']) or die('A crapat cand am executat: '.$_GET['query'].' <br />Eroarea primita: '.mysql_error($mysql));
*/
?>
